//
//  FirstAidViewModel.swift
//  HealthKit
//
//  Created by Than on 26/5/2565 BE.
//

import Foundation

class FirstAidViewModel: ObservableObject {
    @Published private(set) var firstaids: [FirstAid] = []
    
    init() {
        firstaids = FirstAid.all
    }
    
    func addFirstAid(firstaid: FirstAid){
        firstaids.append(firstaid)
    }
}
