//
//  HealthKitApp.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

@main
struct HealthKitApp: App {
    @StateObject var firstAidViewModel = FirstAidViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(firstAidViewModel)
        }
    }
}
