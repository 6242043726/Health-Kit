//
//  Tab.swift
//  HealthKit
//
//  Created by Than on 26/5/2565 BE.
//

import SwiftUI

struct TabItem: Identifiable {
    var id = UUID()
    var text: String
    var icon: String
    var tab: Tab
    var color: Color
}

var tabItems = [
    TabItem(text: "First Aid", icon: "bandage.fill", tab: .home, color: .blue),
    TabItem(text: "Category", icon: "square.fill.text.grid.1x2", tab: .category, color: .teal),
    TabItem(text: "Add", icon: "plus", tab: .newinstruction, color: .orange),
    TabItem(text: "Tools", icon: "bolt.heart.fill", tab: .tools, color: .red)
]

enum Tab: String {
    case home
    case category
    case newinstruction
    case tools
}
