//
//  NewInstructionView.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct NewInstructionView: View {
    @State private var showAddFirstAid = false
    
    var body: some View {
        NavigationView {
            Button("Add New First Aid manunally") {
                showAddFirstAid = true
            }
            .navigationTitle("New Instruction")
        }
        .navigationViewStyle(.stack)
        .sheet(isPresented: $showAddFirstAid){
            AddFirstAidView()
        }
    }
}

struct NewInstructionView_Previews: PreviewProvider {
    static var previews: some View {
        NewInstructionView()
    }
}
