//
//  HomeView.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct HomeView: View {
    
    @EnvironmentObject var firstaidsVM: FirstAidViewModel
    
    var body: some View {
        NavigationView{
            ScrollView{
                FirstAidList(firstaid: firstaidsVM.firstaids)
            }
            .navigationTitle("First Aids")
        }
        .navigationViewStyle(.stack)
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(FirstAidViewModel())
    }
}
