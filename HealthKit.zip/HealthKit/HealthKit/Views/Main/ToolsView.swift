//
//  ToolsView.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct ToolsView: View {
    var body: some View {
        NavigationView{
            ScrollView{
                ToolsList(tools: Tools.all)
            }
            .navigationTitle("Emergency Tools")
        }
        .navigationViewStyle(.stack)
    }
}

struct ToolsView_Previews: PreviewProvider {
    static var previews: some View {
        ToolsView()
    }
}
