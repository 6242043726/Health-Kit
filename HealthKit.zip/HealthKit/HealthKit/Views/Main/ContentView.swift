//
//  ContentView.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabBar()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(FirstAidViewModel())
    }
}
