//
//  FirstAidCard.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct FirstAidCard: View {
    var firstaid: FirstAid
    
    var body: some View {
        ZStack(alignment: .bottom){
            AsyncImage(url: URL(string:firstaid.image)) {image in
                image
                    .resizable()
                    .cornerRadius(20)
                    .frame(width: 180)
                    .scaledToFit()
            }placeholder: {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40, alignment: .center)
                    .foregroundColor(.white.opacity(0.7))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            VStack(alignment: .center){
                Text(firstaid.name)
                    .bold()
            }
            .padding()
            .frame(width: 180, alignment: .center)
            .background(.ultraThinMaterial)
            .cornerRadius(20)
            .offset(y:35)
    
        }
        .frame(width:180, height:180, alignment: .leading)
        .shadow(color: Color.black.opacity(0.3), radius: 15, x: 0, y: 10)
    }
}

struct FirstAidCard_Previews: PreviewProvider {
    static var previews: some View {
        FirstAidCard(firstaid: FirstAid.all[0])
    }
}
