//
//  ToolsCard.swift
//  HealthKit
//
//  Created by Than on 29/5/2565 BE.
//

import SwiftUI

struct ToolsCard: View {
    var tools: Tools
    var body: some View {
        ZStack(alignment: .bottom){
            AsyncImage(url: URL(string:tools.image)) {image in
                image
                    .resizable()
                    .cornerRadius(20)
                    .frame(width: 180)
                    .scaledToFit()
            }placeholder: {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40, alignment: .center)
                    .foregroundColor(.white.opacity(0.7))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            VStack(alignment: .center){
                Text(tools.name)
                    .bold()
            }
            .padding()
            .frame(width: 180, alignment: .center)
            .background(.ultraThinMaterial)
            .cornerRadius(20)
            .offset(y:35)
    
        }
        .frame(width:180, height:180, alignment: .leading)
        .shadow(color: Color.black.opacity(0.3), radius: 15, x: 0, y: 10)
    }
}

struct ToolsCard_Previews: PreviewProvider {
    static var previews: some View {
        ToolsCard(tools: Tools.all[0])
    }
}
