//
//  ToolsList.swift
//  HealthKit
//
//  Created by Than on 29/5/2565 BE.
//

import SwiftUI

struct ToolsList: View {
    var tools: [Tools]
    var body: some View {
        VStack{
            HStack{
                Text("\(tools.count) \(tools.count > 1 ? "items" : "item")")
                    .font(.headline)
                    .fontWeight(.medium)
                    .opacity(0.7)
                Spacer()
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 180), spacing: 15)],spacing: 55){
                NavigationLink(destination: CPRView()){
                    ToolsCard(tools: tools[0])
                }
                NavigationLink(destination: AEDView()){
                    ToolsCard(tools: tools[1])
                }
                NavigationLink(destination: SOSView()){
                    ToolsCard(tools: tools[2])
                }
                NavigationLink(destination: EmergencyView()){
                    ToolsCard(tools: tools[3])
                }
            }
            .padding(.top)
        }
        .padding(.horizontal)
    }
}
struct ToolsList_Previews: PreviewProvider {
    static var previews: some View {
        ScrollView{
            ToolsList(tools: Tools.all)
        }
    }
}

