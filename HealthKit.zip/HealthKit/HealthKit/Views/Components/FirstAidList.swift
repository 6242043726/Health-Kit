//
//  FirstAidList.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct FirstAidList: View {
    var firstaid: [FirstAid]
    var body: some View {
        VStack{
            HStack{
            Text("\(firstaid.count) \(firstaid.count > 1 ? "items" : "item")")
                .font(.headline)
                .fontWeight(.medium)
            .opacity(0.7)
            Spacer()
        }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 180), spacing: 15)],spacing: 55){
                ForEach(firstaid){ firstaid in
                    NavigationLink(destination: FirstAidView(firstaid: firstaid)) {
                        FirstAidCard(firstaid: firstaid)
                    }
                }
                Spacer()
                Spacer()
                Spacer()
                Spacer()
            }
            .padding(.top)
        }
        .padding(.horizontal)
    }
}

struct FirstAidList_Previews: PreviewProvider {
    static var previews: some View {
        ScrollView{
            FirstAidList(firstaid: FirstAid.all)
        }
    }
}
