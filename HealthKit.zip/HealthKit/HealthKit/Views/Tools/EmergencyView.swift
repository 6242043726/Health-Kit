//
//  EmergencyView.swift
//  HealthKit
//
//  Created by Than on 29/5/2565 BE.
//

import SwiftUI

struct EmergencyView: View {
    var body: some View {
        VStack{
            Text("เบอร์โทรฉุกเฉิน")
                .font(.headline)
                .multilineTextAlignment(.center)
            
            Image("EmergencyCall")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: getRect().width - 30)
                .cornerRadius(15)
                .addPinchZoom()
            Spacer()
        }
        .navigationBarTitle("Emergency Call")
    }
}

