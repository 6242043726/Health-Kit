//
//  SOSView.swift
//  HealthKit
//
//  Created by Than on 26/5/2565 BE.
//

import SwiftUI
import UIKit
import AVFoundation

struct SOSView: View{
    @State var sirenIsPaused: Bool = true
    @State var audioPlayer : AVAudioPlayer?
    
    var body: some View {
        VStack{
            Text("Press for \nHelp!")
                .multilineTextAlignment(.center)
                .font(.system(size: 65, weight: .bold, design: .rounded))
                .padding(.all)
            if sirenIsPaused {
                Image(systemName: "speaker.wave.3.fill")
                    .font(.system(size: 72, weight: .bold, design: .rounded))
                    .frame(minWidth: 0, maxWidth: 300, minHeight: 0, maxHeight: 300)
                    .background(Color.red)
                    .foregroundColor(Color.white)
                    .clipShape(Circle())
                    .simultaneousGesture(TapGesture().onEnded(self.startSiren))
                    .padding(.all)
            }
            else{
                Image(systemName: "speaker.slash.fill")
                    .font(.system(size: 72, weight: .bold, design: .rounded))
                    .frame(minWidth: 0, maxWidth: 300, minHeight: 0, maxHeight: 300)
                    .background(Color.green)
                    .foregroundColor(Color.white)
                    .clipShape(Circle())
                    .simultaneousGesture(TapGesture().onEnded(self.stopSiren))
                    .padding(.all)
            }
            Spacer()
        }
        .navigationBarTitle("SOS")
    }
    
    func startSiren(){
        sirenIsPaused = false
        let songPath = Bundle.main.path(forResource:"siren", ofType: "mp3")
        let songURL = URL(fileURLWithPath: songPath!)
        self.audioPlayer = try! AVAudioPlayer(contentsOf:songURL)
        self.audioPlayer?.numberOfLoops = -1
        self.audioPlayer?.play()
    }
    
    func stopSiren(){
        sirenIsPaused = true
        self.audioPlayer?.stop()
    }
}

struct SOSView_Previews: PreviewProvider {
    static var previews: some View {
        SOSView()
    }
}
