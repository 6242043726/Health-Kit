//
//  CPRView.swift
//  HealthKit
//
//  Created by Than on 26/5/2565 BE.
//

import SwiftUI
import AVFoundation

struct HeartBeat : Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.midX-20, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.midX, y: (rect.midY+rect.maxY)/2))
        path.addLine(to: CGPoint(x: rect.midX+10, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.midX+20, y: (rect.midY/2)))
        path.addLine(to: CGPoint(x: rect.midX+40, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        return path
    }
}

struct HeartBeatView : View {
    @State var trimValue1 : CGFloat = 0
    @State var trimValue2 : CGFloat = 0
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            
            HeartBeat()
                .stroke(lineWidth: 8)
                .foregroundColor(Color.black.opacity(0.1))
            
            HeartBeat()
                .trim(from: trimValue1, to: trimValue2)
                .stroke(lineWidth: 8)
                .foregroundColor(.red)
            
        }
        .frame(height: 300)
        .animation(.spring())
        .onReceive(timer, perform: { _ in
            if trimValue2 == 0 {
                trimValue2 = 1
            }
            else if trimValue1 == 0 {
                trimValue1 = 1
            } else {
                trimValue2 = 0
                trimValue1 = 0
            }
        })
    }
}

//counter
struct TimerView: View {
    
    @AppStorage("rounds") var rounds: Int = 0
    @AppStorage("logTime")  var logTime : String = ""
    @AppStorage("times") var times: Int = 0
    @AppStorage("timerIsPaused") var timerIsPaused: Bool = true
    @State var timer: Timer? = nil
    
    @State var audioPlayer : AVAudioPlayer?
    
    var body: some View {
        VStack{
            Text("\(times)")
                .font(.system(size: 100, weight: .bold, design: .rounded))
                .foregroundColor(Color.red)
                .padding(.all)
            HStack{
                Text("Round: \(rounds)")
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .foregroundColor(Color.red)
                Spacer()
                Text("Tempo: 100 bpm")
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .foregroundColor(Color.red)
            }
            .padding([.top, .leading, .trailing],10)
            if timerIsPaused {
                HStack {
                    Image(systemName: "arrow.counterclockwise")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .frame(minWidth: 0, maxWidth: 70, minHeight: 80, maxHeight: 80)
                        .background(Color.red)
                        .foregroundColor(Color.white)
                        .cornerRadius(10)
                        .simultaneousGesture(TapGesture().onEnded({self.restartTimer()
                            self.logTime = ""
                        }))
                    Spacer()
                    HStack{
                        Image(systemName: "play.fill")
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                        Text("Start")
                            .font(.system(size: 36, weight: .bold, design: .rounded))
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 80, maxHeight: 80)
                    .background(Color.red)
                    .foregroundColor(Color.white)
                    .cornerRadius(10)
                    .simultaneousGesture(TapGesture().onEnded({self.startTimer()
                        if(self.rounds == 0 && self.times == 0){
                            self.logTime = "Start at: " + self.getTime()
                        }
                    }
                                                             ))
                }
                .padding(10)
            } else {
                HStack{
                    Image(systemName: "stop.fill")
                    Text("Stop")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 80, maxHeight: 80)
                .background(Color.red)
                .foregroundColor(Color.white)
                .cornerRadius(10)
                .simultaneousGesture(TapGesture().onEnded(self.stopTimer))
                .padding(10)
            }
            Text("\(self.logTime)")
                .font(.system(size: 22, weight: .medium, design: .rounded))
                .foregroundColor(Color.red)
        }
    }
    func getTime() ->String{
        var dateString = ""
        let date = Date()
        let df = DateFormatter()
        df.dateFormat = "dd-MM-YYYY (HH:mm:ss)"
        dateString = df.string(from: date)
        return dateString
    }
    func startTimer(){
        timerIsPaused = false
        timer = Timer.scheduledTimer(withTimeInterval: 0.6, repeats: true){ tempTimer in
            if self.times == 30 {
                self.times = 0
                self.rounds = self.rounds + 1
                stopTimer()
            } else {
                let songPath = Bundle.main.path(forResource:"heartbeat", ofType: "mp3")
                let songURL = URL(fileURLWithPath: songPath!)
                self.audioPlayer = try! AVAudioPlayer(contentsOf:songURL)
                self.audioPlayer?.numberOfLoops = 0
                self.audioPlayer?.play()
                self.times = self.times + 1
            }
        }
    }
    
    func stopTimer(){
        timerIsPaused = true
        timer?.invalidate()
        timer = nil
        self.audioPlayer?.stop()
    }
    
    func restartTimer(){
        rounds = 0
        times = 0
    }
}

//cpr
struct CPRView: View {
    
    var body: some View{
        ScrollView(.vertical, showsIndicators: false){
            VStack{
                HeartBeatView()
                TimerView()
            }
        .navigationBarTitle("CPR Tempo")
    }
}
}


struct CPRView_Previews: PreviewProvider {
    static var previews: some View {
        CPRView()
    }
}
