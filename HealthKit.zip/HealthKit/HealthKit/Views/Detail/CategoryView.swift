//
//  CategoryView.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI

struct CategoryView: View {
    @EnvironmentObject var firstaidsVM: FirstAidViewModel
    
    var category: Category
    
    //computed property
    var firstaid: [FirstAid] {
        return firstaidsVM.firstaids.filter{ $0.category == category.rawValue }
    }
    
    var body: some View {
        ScrollView {
            FirstAidList(firstaid: firstaid)
        }
        .navigationTitle(category.rawValue)
    }
}

struct CategoryView_Previews: PreviewProvider {
    static var previews: some View {
        CategoryView(category: Category.injury)
            .environmentObject(FirstAidViewModel())
    }
}
