//
//  FirstAidView.swift
//  HealthKit
//
//  Created by Than on 25/5/2565 BE.
//

import SwiftUI
import AVFoundation

struct FirstAidView: View {
    var firstaid: FirstAid
    
    var body: some View {
        ScrollView {
            AsyncImage(url: URL(string:firstaid.image)) {image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            }placeholder: {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100, alignment: .center)
                    .foregroundColor(.white.opacity(0.7))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(height:300)
            .background(LinearGradient(gradient: Gradient(colors: [Color(.gray).opacity(0.3), Color(.gray)]), startPoint: .top, endPoint: .bottom))
            VStack(spacing: 30){
                Spacer()
                Spacer()
                Text(firstaid.name)
                    .font(.largeTitle)
                    .bold()
                    .multilineTextAlignment(.center)
                
                VStack(alignment: .leading, spacing: 30){
                    if !firstaid.description.isEmpty {
                        Text(firstaid.description)
                    }
                    
                    if !firstaid.steps.isEmpty {
                        VStack(alignment: .leading, spacing: 20) {
                            HStack{
                                Text("ขั้นตอน")
                                    .font(.headline)
                                Spacer()
                                Button(action: {
                                    let mySpeechUtterance = AVSpeechUtterance(string:"ขั้นตอน" + firstaid.steps)
                                    mySpeechUtterance.voice = AVSpeechSynthesisVoice(language: "th-TH")
                                    let mySpeechSynthesizer = AVSpeechSynthesizer()
                                    mySpeechSynthesizer.speak(mySpeechUtterance)
                                }){
                                    Image(systemName: "speaker.wave.3.fill")
                                        .foregroundColor(Color.red)
                                        .font(.system(size: 20, weight: .bold))
                                }
                            }
                            Text(firstaid.steps)
                        }
                    }
                    if !firstaid.tools.isEmpty {
                        VStack(alignment: .leading, spacing: 20) {
                            HStack{
                            Text("อุปกรณ์")
                                .font(.headline)
                                Spacer()
                                Button(action: {
                                    let mySpeechUtterance = AVSpeechUtterance(string:"อุปกรณ์" + firstaid.tools)
                                    mySpeechUtterance.voice = AVSpeechSynthesisVoice(language: "th-TH")
                                    let mySpeechSynthesizer = AVSpeechSynthesizer()
                                    mySpeechSynthesizer.speak(mySpeechUtterance)
                                }){
                                    Image(systemName: "speaker.wave.3.fill")
                                        .foregroundColor(Color.red)
                                        .font(.system(size: 20, weight: .bold))
                                }
                            }
                            Text(firstaid.tools)
                        }
                    }
                    Spacer()
                    Spacer()
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.horizontal)
        }
        .ignoresSafeArea(.container, edges: .top)
    }
}

struct FirstAidView_Previews: PreviewProvider {
    static var previews: some View {
        FirstAidView(firstaid: FirstAid.all[0])
    }
}
