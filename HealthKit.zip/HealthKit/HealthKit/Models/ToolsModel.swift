//
//  ToolsModel.swift
//  HealthKit
//
//  Created by Than on 29/5/2565 BE.
//

import Foundation

struct Tools: Identifiable {
    let id = UUID()
    let name: String
    let image: String
}

extension Tools{
    static let all: [Tools] = [
        Tools(name:"CPR Tempo",image: "https://img.freepik.com/free-vector/cardiopulmonary-resuscitation-cpr-sign-label-first-aid-emergency-icon-graphic-flat-design-vector-illustration_29393-575.jpg?w=2000"),
        Tools(name:"AED Location",image: "https://thumbs.dreamstime.com/b/defibrillator-symbol-location-icon-vector-illustration-94736893.jpg"),
        Tools(name:"SOS",image: "https://thumbs.dreamstime.com/b/sos-icon-isolated-white-background-vector-illustration-203056082.jpg"),
        Tools(name:"Emergency Call",image: "https://cdn-icons-png.flaticon.com/512/3393/3393648.png"),
    ]}
